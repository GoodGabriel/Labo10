Usare g++ -std=c++11 *.cpp -o tree2

Le operazioni di confronto devono esser scritte in formato >, <, =, >=, <=.

Alla fine dell'albero devone esserci la parola "END" cosi' scritta per far terminare correttamente la predizione.

L'ottava funziona (67,Familiare,) ma non esplicita bene l'errore.

Il menu e il readme vengono presi direttamente dai file .txt per una modifica degli stessi pi� veloce.