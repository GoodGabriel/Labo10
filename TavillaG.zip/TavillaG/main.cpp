// Compilare con g++ -Wall -std=c++11 *.cpp

#include "struct.h"
/* Miglioramenti:

-Se il file menu.txt non esiste che facco?
-Fare il caso in cui i label della due siano incompleti ( non nella forma label:::type)


*/

using namespace std;
using namespace tree;

void readFromStreamFile(istream& str, string& File)
{ string line;
  while (!str.eof())
  {
    getline(str, line);
    File = File + "\n" + line;
  }
  str.clear();
}


void readMenu(string &Menu)
{
  ifstream ifs("menu.txt"); // apertura di uno stream associato ad un file, in lettura
  if (!ifs) Menu = "\nErrore apertura file Menu.txt, impossibile caricare il menu\n";
  readFromStreamFile(ifs, Menu);
}

void readMe(string &ReadMe)
{
  ifstream ifs("README.txt"); // apertura di uno stream associato ad un file, in lettura
  if (!ifs) ReadMe = "\nErrore apertura file ReadME.txt, impossibile caricare le info\n";
  readFromStreamFile(ifs, ReadMe);
}


int main()
{

  string Menu = "";
  readMenu(Menu);


  try {

    string nome_file;
    char ch;
    tree::Label l1, l2, l;

    Tree t = createEmpty();; // da inizializzare però


    cout << Menu;

    while (true)
    {
      cout << "\nDigitare p per stampare il menu, q per terminare\n> ";
      cin >> ch;
      cin.ignore();

      if (ch=='q')
      break;

      switch(ch)
      {
        case '1':
        cin >> nome_file;    // acquisisco il nome del file
        if (!cin) throw runtime_error("Errore inserimento nome file\n");

        t = Dtree::readFromFile(nome_file); // quale redfromfile?
        break;

        case '2':  //Inserimento di un nodo etichettato labelFiglio attaccato a un padre labelPadre
        cout << "Inserire il nuovo elemento (tipo:::argomento) e il padre dell'elemento (tipo:::argomento) :";
        cin >> l1 >> l2; // prendo i due label pero come voglio io
        if (!cin) throw runtime_error("Errore inserimento dati\n");

        if(tree::addElem(l1, l2, t) == FAIL) cout << "Rincontrolla la validità"; // quale insertEleme? e se il padre non si trova?
        break;

        case '3': //Cancellazione di un nodo dall'albero;

        {   while(true)  {
          string newType, newArg;
          cout << "Inserisci il nome completo (tipo:::argomento) da eliminare. "<< endl;
          cout << "Oppure inserisci : 5 - Visualizza; 0 - Esci da elimina;" << endl;
          cin >> l;

          if( l == "5") Dtree::printTree(t , 2);

          else if ( l == "0") break;

          else {

            if(tree::deleteElemI(l, t) == FAIL) cout << endl << "Errore durante l'eliminazione" << endl;
          }
        }
      }
      break;

      case '4':
      {  while(true)  {
        string newType, newArg;
        cout << "Inserisci un valore per continuare; 5 - Visualizza; 0 - Esci da modifica;" << endl;
        cin >> l1;

        if( l1 == "5") Dtree::printTree(t , 2);

        else if ( l1 == "0") break;

        else {
          cout << "Inserisci il nome completo (tipo:::argomento) da modificare: ";
          cin >> l1;
          cout << "Inserisci il nuovo tipo: ";
          cin >> newType;
          cout << "Inserisci il nuovo argomento: ";
          cin >> newArg;
          Dtree::modify( l1, newType, newArg, t);
        }

      }
    }
    break;

    case '5':
    Dtree::printTree(t , 2);
    break;

    case '6':
    Dtree::printTree(t , 1);
    break;

    case '7':
    {
      string valS;
      Dtree::prediction (valS,t);
      cout << "Il valore previsto: " << valS << endl;
      break;
    }
    case '8':
    {
      list::List listina;
      string result;
      cout << "Inserisci i valori cosi' argument,argument :"<< endl;
      cout << "(Senza Spazi dopo la virgola e con virgola in fondo)."<< endl;

      Dtree::prediction_two(result, t, 1 ,listina);
      cout<< "Valore previsto " << result << endl;

      break;
    }
    case '9':
    {
      string ReadMe = "";
      readMe(ReadMe);
      cout << ReadMe << endl;
    }
    break;

    case 'p':
    cout << Menu;
    break;

    default:
    cout << "\nOpzione non valida\n";
  }
}
return 0;
}
catch (runtime_error &msg)
{cerr << "Errore a runtime: " << msg.what() << endl;}
catch (...)
{cerr << "Eccezione non riconosciuta\n";}
}
